//**********************************************************************************//
//											
//		- "Talk to me like I'm a 3 year old!" Programming Lessons -		
//											
//		$Author:	TheTutor -- thetutor@gametutorials.com		
//											
//		$Program:	FPArray						
//											
//		$Description:	A tutorial on "arrays of function pointers"
//											
//**********************************************************************************//

Files:  	main.cpp (The source file containing the actual code)
		menu.cpp (The source file containing the "menu's implementation")
		menu.h (The header file containing the "menu's definitions")
		FPArray.vcxproj  (The VC++ project file holding the project info)
		FPArray.sln  (The solution file holding the solution info)

Instructions:	If you have Microsoft Visual Studio .NET 2005 (version 8.0) just click on the
		<Program Name>.vcxproj file.  This will open up visual c++.  You will most
		likely see the code for <Program Name>.cpp.  If you don't, press CRTL+ALT+L
		This will open the "Solution Explorer".  There you should find two folders named
		"Source Files" and "Header Files".  Double click on the "source" folder and you
		should see your source file(s) with a .cpp extension after it.  Double click on the
		file and it will open up in your main window.  Hit Control-F5 to run the program.
		You will probably see a prompt to compile/build the project.  Click OK and
		a console window should pop up with the program. :)

EULA:  		Your use of this tutorial constitutes your agreement to GameTutorials' Terms of Use found
		at:  http://www.gametutorials.com/TermsOfUse.htm

www.GameTutorials.com
�2000-2006 GameTutorials
